﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UCS.Logic.Enums
{
    class Layouts 
    {
        public enum Layout : int
        {
            Layout1    = 0,
            Layout2    = 2,
            Layout3    = 3,
            WarLayout1 = 1,
            WarLayout2 = 4,
            WarLayout3 = 5
        }
    }
}
