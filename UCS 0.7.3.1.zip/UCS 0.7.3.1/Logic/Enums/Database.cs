﻿namespace UCS.Logic.Enums
{
    public enum Database
    {
        Players = 0,
        Clans = 1,
        ClanWars = 2,
        Battles = 3,
    }
}
