﻿namespace UCS.Logic.Enums
{
    public enum Save
    {
        Mysql = 0,
        Redis = 1,
        Both = 2,
    }
}
