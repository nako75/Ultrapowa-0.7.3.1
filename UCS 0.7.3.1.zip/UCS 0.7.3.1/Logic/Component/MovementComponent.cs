namespace UCS.Logic
{
    internal class MovementComponent : Component
    {
        const int m_vType = 0x01AB3F00;

        public override int Type => 4;
    }
}
