namespace UCS.Logic
{
    internal class HitpointComponent : Component
    {
        const int m_vType = 0x01AB3F00;

        public override int Type => 2;
    }
}
