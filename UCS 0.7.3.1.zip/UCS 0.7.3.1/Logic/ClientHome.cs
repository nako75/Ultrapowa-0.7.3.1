using System.Collections.Generic;
using UCS.Helpers;
using UCS.Helpers.List;

namespace UCS.Logic
{
    internal class ClientHome : Base
    {
        readonly long m_vId;
        string village;
        int m_vShieldTime;
        int m_vProtectionTime;

        public ClientHome()
        {
        }

        public ClientHome(long id)
        {
            m_vId = id;
        }

        public override byte[] Encode()
        {
            List<byte> data = new List<byte>();
            data.AddLong(m_vId);

            data.AddInt(m_vShieldTime); // Shield
            data.AddInt(m_vProtectionTime); // Protection

            data.AddInt(0);
            data.AddCompressed(village);
            data.AddCompressed("{\"event\":[]}");
            return data.ToArray();
        }

        public string GetHomeJSON() => village;

        public void SetHomeJSON(string json) => village = json;

        public void SetShieldTime(int seconds) => m_vShieldTime = seconds;

        public int GetShieldTime() => m_vShieldTime;

        public void SetProtectionTime(int time) => m_vProtectionTime = time;

        public int GetProtectionTime() => m_vProtectionTime;
    }
}
